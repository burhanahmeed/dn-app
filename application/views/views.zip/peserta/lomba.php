<div class="comp">
<h3>Please register yourself before you can continue..</h3>
	<div class="container">
	<h4>Mahasiswa S1/D3/D4/Sederajat</h4><span class="border"></span>
		<div class="sep row">
			<div class="col-md-6 col-sm-6">
				<div class="comp-b bisplan-d hg">
					<h4>Business Plan Competition</h4>
					<img src="https://d30y9cdsu7xlg0.cloudfront.net/png/381701-200.png">
					<div class="join">
						<a href="<?= base_url()?>register/bisplan" class="btn dn-btn-white">Register</a>
					</div>
				</div>
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="comp-b debat-d hg">
					<h4>Debate Competition</h4>
					<img src="https://d30y9cdsu7xlg0.cloudfront.net/png/381701-200.png">
					<div class="join">
						<a href="<?= base_url()?>register/debat" class="btn dn-btn-white">Register</a>
					</div>
				</div>
			</div>
		</div>
		<h4>Siswa SMA/SMK/MA/Sederajat</h4><span class="border"></span>
		<div class="sep row">
			<div class="col-md-6 col-sm-6">
				<div class="comp-b cercer-d hg">
					<h4>Cerdas Cermat Competition</h4>
					<img src="https://d30y9cdsu7xlg0.cloudfront.net/png/381701-200.png">
					<div class="join">
						<a href="<?= base_url()?>register/cercer" class="btn dn-btn-white">Register</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>